"""
URL configuration for SPICES project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from store import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('about',views.about),
    path('cart',views.carts),
    path('checkout',views.checkout),
    path('contact-us',views.contacts),
    path('gallery',views.gallery),
    path('',views.index),
    path('my_account',views.myaccount),
    path('shop',views.shop),
    path('shop_detail',views.shopdetail),
    path('Wishlist',views.Wishlist),
    path('home',views.home),
    path('adminlogin',views.adminlogin),
    path('service',views.service),
    path('show',views.show),
    path('search',views.search),
    path('userlogin',views.userlogin),
    path('viewuser',views.viewuser),
    path('addproduct', views.addproduct),
    path('displayproduct', views.displayproduct),
    path('viewbookings', views.viewbookings),
    path('logout', views.logout),
    path('bookingdetails', views.bookingdetails),
    path('updateproduct/<int:d>', views.updateproduct),
    path('settings', views.settings),
    path('login',views.login),
    path('register',views.Register),
    path('userbooking/<int:d>',views.userbooking),
    path('cancelproduct/<int:d>',views.cancelproduct),
    path('Delete/<int:d>', views.delete),
    path('DELETEPRODUCT',views.DELETEPRODUCT),
    path('contact',views.contactus),
    path('delete_cart/<int:d>',views.delete_cart),
    path('display_cart',views.display_cart),
    path('addcart/<int:d>',views.add_to_cart),
    path('catogary_glass',views.category_glass),
    path('catogary_plastic',views.category_plastic),
    path('catogary_aluminium', views.category_aluminium),
    path('catogary_seeds', views.category_seeds),
    path('catogary_spicebox', views.category_spicebox),
    path('catogary_spices', views.category_spices),
    path('addwishlist/<int:d>', views.addwishlist),
    path('customer_wishlist', views.customer_wishlist),
    path('order/<int:total_amount>', views.cartorder),
    path('cartcheckout/<int:total_amount>',views.cart_checkout),
    path('payment_success/<int:l>',views.payment_success),
    path('remove_wishlist/<int:d>', views.remove_wishlist),
    path('addcart/increment/<int:cart_id>/', views.increment_quantity, name='increment_quantity'),
    path('addcart/decrement/<int:cart_id>/', views.decrement_quantity, name='decrement_quantity'),
    path('profile',views.profile),
    path('updateprofile',views.updateprofile),
    path('billing/<int:total_amount>', views.customerbilling),
    path('forgot',views.forgot_password,name='forgot'),
    path('reset/<token>',views.reset_password,name='reset_password'),
    path('checkout/<int:d>',views.checkout),
    path('edit_status/<int:a>',views.edit_status),
    path('success_page',views.success_page),
    path('product_description/<int:d>',views.product_description)



]
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)