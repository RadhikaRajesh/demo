from django.contrib import admin
from .models import *
admin.site.register(user)
admin.site.register(product)
admin.site.register(booking)
admin.site.register(contact)
admin.site.register(cart)
admin.site.register(order)
admin.site.register(wishlist)
admin.site.register(PasswordReset)

# Register your models here.
