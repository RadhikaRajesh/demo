from django.shortcuts import render
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import*
from django.contrib import messages
from django.utils import timezone
import datetime
import os
from django.core.mail import send_mail
from .models import user
import razorpay
import pytz
from django.contrib.auth.models import User,auth
from django.contrib.auth import logout
from django.utils.crypto import get_random_string
from django.contrib.auth.decorators import login_required


def about(request):
    return render(request,'about.html')

def carts(request):
    d=product.objects.all()
    return render(request,'cart.html',{'data':d})

def checkout(request,d):
    User = user.objects.get(email=request.session['user'])
    pro = product.objects.get(pk=d)
    if request.method == 'POST':
        k = request.POST.get('chqty')
        l = int(request.POST.get('chtotal'))
        val = order.objects.create(user_details=User, item_details=pro, ordered_quantity=k, total_price=l )
        val.save()
        return redirect(payment_success,l)
    return render(request, 'checkout.html', {'data': User,'d':pro})

def contacts(request):
    if request.method == 'POST':
        a = request.POST['name']
        b = request.POST['email']
        c = request.POST['phone']
        d = request.POST['message']
        print(a, b, c, d)
        data = contact.objects.create(name=a, email=b, phone=c, message=d)
        data.save()
        messages.success(request, 'data saved')
        return render(request,'contact-us.html')
    return render(request,'contact-us.html')

def contactus(request):
    data = contact.objects.all()
    print(data)
    return render(request, 'contact.html',{'data':data})

def gallery(request):
    return render(request,'gallery.html')

def index(request):
    return render(request,'index.html')

def myaccount(request):
    return render(request,'my-account.html')

def shop(request):
    return render(request,'shop.html')

def shopdetail(request):
    return render(request,'shop-detail.html')

def Wishlist(request):
    return render(request,'wishlist.html')
# Create your views here.
def home(request):
    return render(request,'home.html')
def adminlogin(request):
    if 'admin' in request.session:
        data=product.objects.all()
        return render(request,'adminlogin.html',{'data':data})
    return redirect(login)
def service(request):
    return render(request,'service.html')
def show(request):
    return render(request,'show.html')
def search(request):
    return render(request,'search.html')
def login(request):
    if request.method == 'POST':
        e = request.POST['email']
        p = request.POST['password']
        print(e,p)
        try:
            data = user.objects.get(email=e)
            print(data, data.password)
            print(type(data))
            print("%%%%%%%%%%%%%%%%%%%%%%%%%")
            if data.password == p:
                print("1111111111111111111")
                request.session["user"] = e
                return redirect(userlogin)
            else:
                messages.error(request, 'password incorrect')
        except Exception:
            if e == 'admin@gmail.com' and p == 'admin':
                request.session["admin"] = e
                return redirect(adminlogin)
            else:
                messages.error(request, 'password incorrect')
    return render(request, 'login.html')

def viewuser(request):
    d =user.objects.all()
    return render(request,'viewuser.html', {'data': d})
def addproduct(request):
    if 'admin' in request.session:
        return render(request,'addproduct.html')
    return redirect(index)
def displayproduct(request):
    return render(request,'displayproduct.html')
def viewbookings(request):
        if 'user' in request.session:
            d = order.objects.all()
            return render(request, 'viewbookings.html', {'data': d})
        return redirect(login)

def logout(request):
    return redirect(login)
def userlogin(request):
    if 'user' in request.session:
        data=product.objects.all()
        return render(request,'userlogin.html',{'data':data})
    return redirect(login)
def userbooking(request,d):
    if 'user' in request.session:
        if request.method == 'POST':
            x=user.objects.get(email=request.session['user'])
            y=product.objects.get(pk=d)
            z=datetime.datetime.now()
            b = int(request.POST['price'])
            c = int(request.POST['quantity'])
            d = int(request.POST['total'])
            data =booking.objects.create(user_details=x,item_details=y,date=z,quantity=c,item_price=b,total_price=d)
            data.save()
            return redirect(bookingdetails)
        data = product.objects.filter(pk=d)
        return render(request,'userbooking.html',{'data':data})
    return redirect(login)
def bookingdetails(request):
    if 'user' in request.session:
        a=user.objects.get(email=request.session['user'])
        data=order.objects.filter(user_details=a)
        return render(request, 'bookingdetails.html',{'data':data})
    return redirect(login)
def cancelproduct(request,d):
    data=booking.objects.filter(item_details=d)
    data.delete()
    messages.success(request,'successfully order cancelled')
    return redirect(bookingdetails)

from .forms import *
def updateproduct(request,d):
    print("PPPPPPPPPPPPPPPPpp")
    data = product.objects.get(pk=d)
    print(data)
    nm=mform(instance=data)
    if 'admin' in request.session:
        print("############3")
        if request.method == 'POST':
            print("get")
            n=mform(request.POST,request.FILES,instance=data)
            if n.is_valid():
                n.save()
                print("hello")
                messages.success(request,'updated')
                return redirect(adminlogin)

        return render(request, 'updateproduct.html', {'data': nm})
    return redirect(login)




def settings(request):
    return render(request,'settings.html')
def Register(request):
    if request.method == 'POST':
        a = request.POST['name']
        b = int(request.POST['phone'])
        c = request.POST['email']
        d = request.POST['password']
        e = request.POST['address']
        print(a,b,c,d,e)

        if user.objects.filter(email=c).exists():
                messages.error(request, 'User already exists with this email, use different email')
                return redirect(Register)
        else:
            data = user.objects.create(name=a, phone=b, email=c, password=d, address=e)
            data.save()
            messages.success(request, 'Successfully registered new user')
        return redirect(login)
    return render(request, 'register.html')
def addproduct(request):
    if 'admin' in request.session:
        if request.method=='POST':
            a=request.POST['name']
            b=int(request.POST['price'])
            c=int(request.POST['quantity'])
            d=request.FILES['image']
            e = request.POST['categories']
            f = request.POST['description']
            data=product.objects.create(name=a,price=b,quantity=c,image=d,category=e,description=f)
            data.save()
            messages.success(request,'data saved')
        return render(request,'addproduct.html')
    return redirect(login)
def delete(request,d):
    if 'admin' in request.session:
        d=product.objects.get(pk=d)
        d.delete()
        messages.success(request,'saved')
        return redirect(adminlogin)
    return render(request, 'viewuser.html', {'data':d})

def delete_cart(request,d):
    if 'user' in request.session:
        print(d)
        data=cart.objects.get(pk=d)
        data.delete()
        return redirect(display_cart)

def update(request,d):
    if request.method=='POST':
        a=request.POST['name']
        b=int(request.POST['age'])
        c=int(request.POST['roll'])
        user.objects.filter(name=a).update(email=b,phone=c)
        messages.succes(request,'updated')
    data=user.objects.filter(name=d)
    return render(request,'update.html',{'data':data})
def DELETEPRODUCT(request):
    d = product.objects.all()
    return render(request,'adminlogin.html', {'data': d})
    return redirect(adminlogin())
def add_to_cart(request,d):
    u=user.objects.get(email=request.session['user'])
    print(u)
    prod_details=product.objects.get(pk=d)
    c=datetime.datetime.now()
    data=cart.objects.create(user_details=u,item_details=prod_details,date=c)
    data.save()
    messages.success(request,'Cart Added Successfully')
    return redirect(display_cart)
def display_cart(request): #To display the customer cart
    d = user.objects.get(email=request.session['user'])
    data = cart.objects.filter(user_details=d)
    qty = 0
    total = 0
    for i in data:
        qty += i.quantity
        total += i.item_details.price * i.quantity
    print(total)
    if not data:
            messages.info(request, 'No items in the cart.')
            return render(request, 'cart.html')
    return render(request, 'cart.html', {'data': data, 'total': total,'qty':qty})


# def increment_quantity(request, cart_id):
#     data = cart.objects.get(pk=cart_id)
#     if data.item_details.quantity > 1:
#         data.quantity += 1
#         data.save()
#         data.total_price = data.quantity * data.item_details.price
#         data.save()
#     return redirect(display_cart)
#
#
# def decrement_quantity(request, cart_id):
#     data = cart.objects.get(pk=cart_id)
#     if data.quantity > 1:
#         data.quantity -= 1
#         data.save()
#     return redirect(display_cart)
def increment_quantity(request, cart_id):
    try:
        data = cart.objects.get(pk=cart_id)
    except cart.DoesNotExist:
        messages.info(request, 'Item not found')
        return redirect(display_cart)  # Redirect if the cart item is not found

    if data.quantity >= 10:
        messages.warning(request, 'Out of stock')
        return redirect(display_cart)  # Redirect if the quantity limit is reached

    if data.item_details.quantity > data.quantity:  # Ensuring stock is available
        data.quantity += 1
        data.total_price = data.quantity * data.item_details.price
        data.save()
    else:
        messages.warning(request, 'Not enough stock available')

    return redirect(display_cart)

# def decrement_quantity(request, cart_id):
#     data = cart.objects.get(pk=cart_id)
#     if data.quantity > 1:
#         data.quantity -= 1
#         data.save()
#         data.delete()
#     return redirect(display_cart)
def decrement_quantity(request, cart_id):
    try:
        data = cart.objects.get(pk=cart_id)
    except cart.DoesNotExist:
        messages.info(request, 'Item not found')
        return redirect('display_cart')  # Redirect if the cart item is not found

    if data.quantity > 1:
        data.quantity -= 1
        data.total_price = data.quantity * data.item_details.price  # Update the total price
        data.save()
    else:
        data.delete()

    return redirect(display_cart)



def category_glass(request):
    if 'user' in request.session:
        a=product.objects.filter(category='Glass Waterbottles')
        return render(request, 'category_glass.html',{'data':a})
def category_plastic(request):
    if 'user' in request.session:
        b=product.objects.filter(category='Plastic Waterbottles')
        print(b)
        return render(request, 'category_plastic.html',{'data':b})
def category_aluminium(request):
    if 'user' in request.session:
        c=product.objects.filter(category='Aluminium Waterbottles')
        return render(request, 'category_aluminium.html',{'data':c})
def category_spices(request):
    if 'user' in request.session:
        d=product.objects.filter(category='spices')
        return render(request, 'category_spices.html',{'data':d})
def category_seeds(request):
    if 'user' in request.session:
        d=product.objects.filter(category='seeds')
        return render(request, 'category_seeds.html',{'data':d})
def category_spicebox(request):
    if 'user' in request.session:
        d=product.objects.filter(category='spicebox')
        return render(request, 'category_spicebox.html',{'data':d})

def cartorder(request, total_amount):  #To order items from the cart
    if 'user' in request.session:
        user_email = request.session['user']
        request.session['total']=total_amount
        t=request.session['total']
        try:
            u= user.objects.get(email=user_email)
            user_address = u.address
        except user.DoesNotExist:
            user_address = "Default Address"
        status = 'Paid'
        amount = int(t) * 100
        client = razorpay.Client(auth=("rzp_test_SROSnyInFv81S4", "WIWYANkTTLg7iGbFgEbwj4BM"))
        payment = client.order.create({'amount': amount, 'currency': 'INR', 'payment_capture': '1'})

        if 'id' in payment:
            cart_items = cart.objects.filter(user_details=u)
            # Check stock availability for each item in the cart
            for cart_item in cart_items:
                if cart_item.item_details.quantity >= cart_item.quantity:
                    cart_item.item_details.quantity -= cart_item.quantity
                    cart_item.item_details.save()

                    # Reduce the stock based on the cart item quantity
                    new_order = order.objects.create(
                        item_details=cart_item.item_details,
                        user_details=u,
                        address=user_address,
                        product_status=status,
                        total_price=total_amount,
                        ordered_quantity=cart_item.quantity,

                    )
                    new_order.save()
                    cart_item.delete()
                else:
                    messages.warning(request, f'Item "{cart_item.item_details.name}" does not have sufficient stock.')
                    return render(request, "order.html")
            print(amount)
            messages.success(request,'Proceed to Payment! ')
            return render(request, "order.html", {'amount': amount})
        else:
            messages.error(request, 'Payment failed. Please try again.')
        return render(request, "order.html")
    return redirect(payment_success,total_amount)
def cart_checkout(request, total_amount):  #To order items from the buynow
    if 'user' in request.session:
        user_email = request.session['user']
        try:
            u= user.objects.get(email=user_email)
            user_address = u.address
        except user.DoesNotExist:
            user_address = "Default Address"
        status = 'Paid'
        amount = int(total_amount) * 100
        request.session['amount']=amount
        t=request.session['amount']
        print(t)

        client = razorpay.Client(auth=("rzp_test_SROSnyInFv81S4", "WIWYANkTTLg7iGbFgEbwj4BM"))
        payment = client.order.create({'amount': t, 'currency': 'INR', 'payment_capture': '1'})
        if 'id' in payment:
            cart_items = cart.objects.filter(user_details=u)
            # Check stock availability for each item in the cart
            for cart_item in cart_items:
                if cart_item.item_details.quantity >= cart_item.quantity:
                    cart_item.item_details.quantity -= cart_item.quantity
                    cart_item.item_details.save()

                    # Reduce the stock based on the cart item quantity
                    new_order = order.objects.create(
                        item_details=cart_item.item_details,
                        user_details=u,
                        address=user_address,
                        status=status,
                        ordered_quantity=cart_item.quantity,

                    )
                    new_order.save()
                    cart_item.delete()
                else:
                    messages.warning(request, f'Item "{cart_item.item_details.name}" does not have sufficient stock.')
                    return render(request, "order.html")

            messages.success(request,'Proceed to Payment! ')
            return render(request, "order.html", {'payment': t})
        else:
            messages.error(request, 'Payment failed. Please try again.')
        return render(request, "order.html")
    return redirect(payment_success,total_amount)
def payment_success(request,l):
    if 'user' in request.session:
        user_email = request.session['user']
        u= user.objects.get(email=user_email)
        orders = order.objects.filter(user_details=u)

        for order_item in orders:
            product_name = order_item.item_details.name

            subject = 'Payment Successful'
            message = f"Dear {u.name},\n\nYour payment was successful for the following product:\n"
            message += f"Product Name: {product_name}\n\nThank you for your purchase. Your product will be delivered soon.\n\nBest regards,\nFlour Delight"
            if order_item.item_details.quantity < 5:
                print(product_name, order_item.item_details.quantity)
                # send_email(product_name, order_item.item_details.quantity)
            try:
                send_mail(subject, message, 'your_email@example.com', [u.email])
                # messages.success(request, 'Email sent successfully!')
            except Exception as e:
                messages.error(request, f'Failed to send email. Error: {str(e)}')
        return render(request, "paymentsuccess.html",{'user':user,'t':l*100})

def addwishlist(request, d):
    if 'user' in request.session:
        u = user.objects.get(email=request.session['user'])
        item = product.objects.get(pk=d)
        ist_timezone = pytz.timezone('Asia/Kolkata')
        current_date = timezone.now().astimezone(ist_timezone)
        # Set the time zone to IST
        wishlist.objects.create(item_details=item, user_details=u,date=current_date).save()
        print("saved")
        messages.success(request, 'Item Added to Wish List Successfully')
        return redirect(customer_wishlist)
    return redirect(login)


def customer_wishlist(request):
    if 'user' in request.session:
        user_id= user.objects.get(email=request.session['user'])
        wishlist_items=wishlist.objects.filter(user_details=user_id)
        return render(request,'customer_wishlist.html',{'wishlist_items': wishlist_items})
    return redirect(index)

def remove_wishlist(request,d):
    wishlist.objects.get(pk=d).delete()
    return redirect(customer_wishlist)
def profile(request):
    a=user.objects.get(email=request.session['user'])
    return render (request,'profile.html',{'data':a})
def updateprofile(request):
    if 'user' in request.session:
        if request.method == 'POST':
            a = request.POST.get('pname')
            b = request.POST.get('pphone')
            c = request.POST.get('paddress')
            d = request.POST.get('pcity')
            e = request.POST.get('ppincode')
            f = request.POST.get('pstate')

            user.objects.filter(email=request.session['user']).update(name=a, phone=b, address=c, city=d, pincode=e, state=f)
            return redirect(profile)

def customerbilling(request, total_amount):
        if 'user' in request.session:
            data = user.objects.get(email=request.session['user'])
            if request.method == 'POST':
                data.city = request.POST['pcity']
                data.pincode = request.POST['ppincode']
                data.state = request.POST['pstate']
                data.save()
                return redirect(cartorder, total_amount)
            return render(request, 'billing_details.html', {'data': data})
        return redirect(login)





def forgot_password(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            User = user.objects.get(email=email)
        except:
            messages.info(request,"Email id not registered")
            return redirect(forgot_password)
        # Generate and save a unique token
        token = get_random_string(length=4)
        PasswordReset.objects.create(user=User, token=token)

        # Send email with reset link
        reset_link = f'http://127.0.0.1:8000/reset/{token}'
        try:
            send_mail('Reset Your Password', f'Click the link to reset your password: {reset_link}','settings.EMAIL_HOST_USER', [email],fail_silently=False)
            # return render(request, 'emailsent.html')
        except:
            messages.info(request,"Network connection failed")
            return redirect(forgot_password)

    return render(request, 'forget_password.html')

def reset_password(request, token):
    # Verify token and reset the password
    print(token)
    password_reset = PasswordReset.objects.get(token=token)
    usr = user.objects.get(id=password_reset.user_id)
    if request.method == 'POST':
        new_password = request.POST.get('newpassword')
        repeat_password = request.POST.get('cpassword')
        if repeat_password == new_password:
            password_reset.user.password=new_password
            password_reset.user.save()
            # password_reset.delete()
            return redirect(login)
    return render(request, 'reset_password.html',{'token':token})

def edit_status(request,a):
    if 'user' in request.session:
        if request.method == 'POST':
            status = request.POST.get('odsts')
            inst =  request.POST.get('inst')
            order.objects.filter(pk=a).update(product_status=status,instruction=inst)
            return redirect(viewbookings)
        return render(request, 'edit_status.html')
    return redirect(login)
def success_page(request):
    if request.method == 'POST':
        return render(request,"success_page.html")
    return render(request, "success_page.html")
def product_description(request,d):
    data=product.objects.get(pk=d)
    return render(request,'product_description.html',{'data':data})
def send_email(productname, quantity):
    a = product.objects.all()
    if a.objects.quantity < 5:

        print(
        f"Email Configuration: {settings.EMAIL_HOST}, {settings.EMAIL_PORT}, {settings.EMAIL_USE_TLS}, {settings.EMAIL_HOST_USER}")
    subject = 'Low Stock Alert'
    message = f"Product Stock Alert: {productname} has low stock. Current quantity: {quantity}. Restock now!"
    from_email = 'spicesa6@gmail.com'
    recipient_list = ['spicesa6@gmail.com']  # Admin's email address
    send_mail(subject, message, from_email,recipient_list)