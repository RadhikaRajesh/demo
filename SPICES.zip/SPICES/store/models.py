from django.db import models

# Create your models here.
class user(models.Model):
    name=models.CharField(max_length=20)
    email=models.CharField(max_length=50)
    phone=models.IntegerField()
    password=models.CharField(max_length=10)
    address=models.CharField(max_length=50)
    city = models.CharField(null=True, max_length=10)
    pincode = models.IntegerField(null=True)
    state = models.CharField(null=True, max_length=10)
    def __str__(self):
       return self.name

class product(models.Model):
    categorychoices=(
        ('a','Glass Waterbottles'),
        ('b','Plastic Waterbottles'),
        ('c','Aluminium Waterbottles'),
    )
    name=models.CharField(max_length=45)
    price=models.IntegerField()
    quantity=models.IntegerField()
    image=models.FileField()
    category=models.CharField(max_length=50)
    description=models.CharField(max_length=1000)
    def __str__(self):
       return self.name

class booking(models.Model):
    user_details=models.ForeignKey(user,on_delete=models.CASCADE)
    item_details=models.ForeignKey(product,on_delete=models.CASCADE)
    date=models.DateTimeField()
    quantity=models.IntegerField()
    item_price=models.IntegerField()
    total_price=models.IntegerField()
class cart(models.Model):
    user_details=models.ForeignKey(user,on_delete=models.CASCADE)
    item_details=models.ForeignKey(product,on_delete=models.CASCADE)
    quantity=models.IntegerField(default=1)
    total_price=models.IntegerField(default=0)
    date=models.DateTimeField()
class contact(models.Model):
    name=models.CharField(max_length=10)
    email=models.CharField(max_length=10)
    phone=models.IntegerField()
    message=models.CharField(max_length=10)
class wishlist(models.Model):
    item_details=models.ForeignKey(product,on_delete=models.CASCADE)
    user_details=models.ForeignKey(user,on_delete=models.CASCADE)
    date=models.DateTimeField(auto_now_add=True)
class order(models.Model):
    item_details=models.ForeignKey(product, on_delete=models.CASCADE, null=True)
    user_details=models.ForeignKey(user,on_delete=models.CASCADE)
    total_price=models.IntegerField()
    address=models.CharField(max_length=30)
    ordered_quantity = models.PositiveIntegerField(default=1)
    instruction = models.CharField(max_length=50, null=True, default='Your Order Has Been Successfully Placed')
    product_status = models.CharField(max_length=50, null=True, default='Order Placed')
    status_message = models.CharField(max_length=255, blank=True,null=True)
class PasswordReset(models.Model):
    user = models.ForeignKey(user, on_delete=models.CASCADE)
    token = models.CharField(max_length=20)
    date = models.DateTimeField(auto_now=True)