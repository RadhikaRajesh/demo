from django import forms
from .models import *
class mform(forms.ModelForm):
    class Meta:
        model=product
        fields='__all__'

